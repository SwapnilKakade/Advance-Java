package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	void addNewProduct_Warehouse();

	List<Product> getAllProducts();

	boolean DeleteByid(int pid);

	Product DisplayByid(int pid);

	List<Product> SortById();

	void closeSessionFactory();

	boolean UpdateByid(int pid, String pname, String wname);

}
