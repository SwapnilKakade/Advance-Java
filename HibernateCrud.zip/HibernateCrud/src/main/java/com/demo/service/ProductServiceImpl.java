package com.demo.service;
import java.util.List;
import java.util.Scanner;
import com.demo.beans.*;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	
	private ProductDao prodDao;

	public ProductServiceImpl() {
		super();
		this.prodDao = new ProductDaoImpl();
	}

	public void addNewProduct_Warehouse() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the pid");
		int pid = sc.nextInt();
		System.out.println("Enter the pname");
		String pname = sc.next();
		System.out.println("Enter the wid");
		int wid = sc.nextInt();
		System.out.println("Enter the wname");
		String wname = sc.next();
		System.out.println("Enter the wloc");
		String wloc = sc.next();
		Warehouse w = new Warehouse(wid,wname,wloc);
		Product p = new Product(pid,pname,w);
		prodDao.saveData(p);
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		return prodDao.findAllProduct();
	}

	@Override
	public boolean DeleteByid(int pid) {
		return prodDao.DeleteById(pid);
	}

	@Override
	public Product DisplayByid(int pid) {
		// TODO Auto-generated method stub
		return prodDao.DisplayById(pid);
	}

	@Override
	public List<Product> SortById() {
		
		return prodDao.SortById();
	}

	@Override
	public void closeSessionFactory() {
		prodDao.closeConnection();

	}

	@Override
	public boolean UpdateByid(int pid, String pname, String wname) {
	
		return prodDao.UpdateByid(pid,pname,wname);
	}
	

}
