package com.demo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.demo.beans.Product;

public class ProductDaoImpl implements ProductDao {

	private static SessionFactory sf ;
	static {
		sf = HibernateUtil.getMySessionFactory();
	}
	
	public void saveData(Product p) {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		sess.save(p);
		tr.commit();
		sess.close();
	}

	@Override
	public List<Product> findAllProduct() {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Query query = sess.createQuery("from Product");
		List<Product> plist = query.list();
		tr.commit();
		sess.close();
		return plist;
	}

	@Override
	public boolean DeleteById(int pid) {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Product p = sess.get(Product.class,pid);
		if(p != null) {
			sess.delete(p);
			tr.commit();
			sess.close();
			return true;
		}
		tr.commit();
		sess.close();
		return true;
	}

	@Override
	public Product DisplayById(int pid) {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Product p = sess.get(Product.class,pid);
		tr.commit();
		sess.close();
		return p;
	}

	@Override
	public List<Product> SortById() {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Query q = sess.createQuery("from Product p order by p.pid desc");
		List<Product> plist = q.list();
		tr.commit();
		sess.close();
		return plist;
	}

	@Override
	public void closeConnection() {
		
		HibernateUtil.closeMySessionFactory();
	}

	@Override
	public boolean UpdateByid(int pid, String pname, String wname) {
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Product p = sess.get(Product.class,pid);
		if(p != null) {
			p.setPname(pname);
			p.getWhouse().setWname(wname);
			tr.commit();
			sess.close();
			return true;
		}
		tr.commit();
		sess.close();
		return false;
	}
	
		
	
}
