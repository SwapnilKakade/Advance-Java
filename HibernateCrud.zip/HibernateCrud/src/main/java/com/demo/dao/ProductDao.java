package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {

	void saveData(Product p);

	List<Product> findAllProduct();

	boolean DeleteById(int pid);

	Product DisplayById(int pid);

	List<Product> SortById();

	void closeConnection();

	boolean UpdateByid(int pid, String pname, String wname);

}
