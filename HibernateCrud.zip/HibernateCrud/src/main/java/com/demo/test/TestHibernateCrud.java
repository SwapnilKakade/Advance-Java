package com.demo.test;
import java.util.List;
import java.util.Scanner;

import com.demo.beans.Product;
import com.demo.service.*;
public class TestHibernateCrud {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		ProductService ps = new ProductServiceImpl();
		int choice= 0;
		do {
			System.out.println("1. Add new product\n"
					+ "2. Delete by id\n "
					+ "3. Display all\n"
					+ "4. display by Id\n"
					+ "5. sort by id\n"
					+ "6. update by id\n"
					+ "7. exit\n"
					+ "choice: ");
			choice = sc.nextInt();
			
			switch(choice) {
			
			case 1:
				ps.addNewProduct_Warehouse();
				break;
				
			case 2:
				System.out.println("Enter the pid");
				int pid = sc.nextInt();
				boolean status =ps.DeleteByid(pid);
				if(status) {
					System.out.println("Delete Sucessfully");
				}
				else {
					System.out.println("Not found");
				}
				break;
				
			case 3:
				List<Product> plist = ps.getAllProducts();
				plist.forEach(System.out::println);
				break;
				
			case 4:
				System.out.println("Enter the pid");
				pid = sc.nextInt();
				Product p =ps.DisplayByid(pid);
				if(p != null) {
					System.out.println(p);
				}
				else {
					System.out.println("Not found");
				}
				break;
				
			case 5:
				plist = ps.SortById();
				plist.forEach(System.out::println);

				break;
				
			case 6:
				System.out.println("Enter the pid");
				pid = sc.nextInt();
				System.out.println("Enter the pname");
				String pname = sc.next();
				System.out.println("Enter the wname");
				String wname= sc.next();
				status =ps.UpdateByid(pid,pname,wname);
				if(status) {
					System.out.println("Modified Sucessfully");
				}
				else {
					System.out.println("Not found");
				}
				break;
				
			case 7:
				ps.closeSessionFactory();
				System.out.println("Thank you for visiting");
				break;
				
			default :
				System.out.println("You enter wrong chioce");
			}
			
		}while(choice != 7);
	}

}
