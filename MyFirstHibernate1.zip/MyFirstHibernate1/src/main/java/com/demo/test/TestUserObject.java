package com.demo.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.demo.beans.Myuser;
public class TestUserObject {

	public static void main(String[] args) {
		//object is in transient state
		Myuser u2 = new Myuser(12,"sk","sdf@df");
		//step 1 create session factory object
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
	
		//step2 create session
		Session sess=sf.openSession();
		//sf.getCurrentSession();
		Transaction tr=sess.beginTransaction();
		sess.save(u2);
		tr.commit();
		sess.close();
		
		
//		Session sess1=sf.openSession();
//		//sf.getCurrentSession();
//		Transaction tr1=sess1.beginTransaction();
//		MyUser u2=sess1.get(MyUser.class,13);
//		
//		tr1.commit();
//		System.out.println(u2);
//		sess1.close();
//		sf.close();

	}

}
