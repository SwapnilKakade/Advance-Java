package Connection;

import java.sql.*;

public class TestConnection {

	public static void main(String[] args) {
	
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			String url = "jdbc:mysql://192.168.10.150:3306/dac44";
					
			Connection con = DriverManager.getConnection(url,"dac44","welcome");
				
			if(con != null) {
				System.out.println("Done");
			}
			else {
				System.out.println("Not done");
			}
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from emp");
				
			while(rs.next()) {
				System.out.println("id :"+rs.getInt(1));
				System.out.println("Name :"+rs.getString(2));
				System.out.println();
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
}
