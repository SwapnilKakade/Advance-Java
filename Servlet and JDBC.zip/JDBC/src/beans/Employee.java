package beans;

public class Employee {
	private int EMPNO ;
	private String ENAME ;
	private double SAL;

	public Employee() {
		super();
	}


	public Employee(int EMPNO, String ENAME, double SAL) {
		super();
		this.EMPNO = EMPNO;
		this.ENAME = ENAME;
		this.SAL = SAL;
	}


	public int getEMPNO() {
		return EMPNO;
	}


	public void setEMPNO(int EMPNO) {
		EMPNO = EMPNO;
	}


	public String getENAME() {
		return ENAME;
	}


	public void setENAME(String ENAME) {
		ENAME = ENAME;
	}


	public double getSAL() {
		return SAL;
	}


	public void setSAL(double SAL) {
		this.SAL = SAL;
	}


	@Override
	public String toString() {
		return "Employee [EMPNO=" + EMPNO + ", ENAME=" + ENAME + ", SAL=" + SAL + "]";
	}
	

}
