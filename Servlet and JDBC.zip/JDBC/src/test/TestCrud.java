package test;

import java.util.List;
import java.util.Scanner;

import beans.Employee;
import service.EmployeeService;
import service.EmployeeServiceImp;

public class TestCrud {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeService es = new EmployeeServiceImp();
		int choice ;
		
		do {
			System.out.println("1. Add new Employee\n"
					+ "2. Delete employee\n"
					+ "3. Modify employee\n"
					+ "4. Display all\n"
					+ "5. Display by id\n"
					+ "6. Display in sorted order\n"
					+ "7. Exit\n"
					+ "Enter your choice :");
			choice = sc.nextInt();
			
			switch(choice) {
				case 1 :
					es.AddNewEmployee();
					break;
				case 2 :
					System.out.println("Enter the Employee No");
					int EMPNO = sc.nextInt();
					boolean status = es.DeleteById(EMPNO);
					if(status) {
						System.out.println("Sucessfully deleted");
					}else {
						System.out.println("Not found");
					}
					break;
				case 3:
					System.out.println("Enter the Employee No");
					EMPNO = sc.nextInt();
					System.out.println("Enter the Salary");
					double SAL = sc.nextDouble();
				    status = es.ModifySal(EMPNO,SAL);
				    if(status) {
				    	System.out.println("Modify Sucessfully");
				    }else {
				    	System.out.println("Not found");
				    }
				    break;
				case 4:
					List<Employee> list = es.DisplayAll();
					list.forEach(System.out::println);
					break;
					
				case 5 :
					System.out.println("Enter the Employee No");
					EMPNO = sc.nextInt();
					Employee e = es.DisplayById(EMPNO);
					if(e!= null) {
						System.out.println(e);
					}else {
						System.out.println("Not found");
					}
					break;
				
				case 6 :
					list = es.DisplaySort();
					list.forEach(System.out::println);
					break;
				case 7 :
					es.closeConnection();
					System.out.println("Thank for visiting.....");
					break;
			}
			
		}while(choice != 7);
	}
}
