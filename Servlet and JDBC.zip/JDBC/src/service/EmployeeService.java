package service;

import java.util.List;

import beans.Employee;

public interface EmployeeService {

	void AddNewEmployee();

	List<Employee> DisplayAll();

	Employee DisplayById(int EMPNO);

	boolean DeleteById(int EMPNO);

	void closeConnection();

	boolean ModifySal(int EMPNO, double SAL);

	List<Employee> DisplaySort();


}
