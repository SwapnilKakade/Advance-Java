package service;

import java.util.List;
import java.util.Scanner;

import beans.Employee;
import dao.EmployeeDao;
import dao.EmployeeDaoImp;
public class EmployeeServiceImp implements EmployeeService {

	private EmployeeDao edao;
	
	

	public EmployeeServiceImp() {
		super();
		this.edao = new EmployeeDaoImp();
	}



	@Override
	public void AddNewEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Employee No");
		int EMPNO = sc.nextInt();
		System.out.println("Enter the Employee Name");
		String ENAME = sc.next();
		System.out.println("Enter the salary");
		Double SAL = sc.nextDouble();
		
		Employee e = new Employee(EMPNO,ENAME,SAL);
		edao.save(e);
	}



	@Override
	public List<Employee> DisplayAll() {
		
		return edao.getAllEmployes();
	}



	@Override
	public Employee DisplayById(int EMPNO) {
		
		return edao.getById(EMPNO);
	}



	@Override
	public boolean DeleteById(int EMPNO) {
		return edao.getDeleteById(EMPNO);
	}



	@Override
	public void closeConnection() {
		edao.closeConnection();
	}



	@Override
	public boolean ModifySal(int EMPNO, double SAL) {
		return edao.getModifySal(EMPNO,SAL);
	}



	@Override
	public List<Employee> DisplaySort() {
		return edao.DisplaySort();
	}

	

}
