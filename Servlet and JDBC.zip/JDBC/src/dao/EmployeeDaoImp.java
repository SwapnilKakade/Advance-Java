package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Employee;

public class EmployeeDaoImp implements EmployeeDao{
	
	private static Connection con ;
	private static PreparedStatement psins,psget,psgetById,psdelById,psUpdate,psSort;
	static {
		
		try {
			con=DButil.getMyConnection();
			psins = con.prepareStatement("insert into Employee values(?,?,?)");
			psget = con.prepareStatement("Select * from Employee");
			psgetById = con.prepareStatement("Select * from Employee where EMPNO =?");
			psdelById = con.prepareStatement("Delete * from Employee where EMPNO =?");
			psUpdate = con.prepareStatement("Update Employee set sal=?,where EMPNO = ?");
			psSort = con.prepareStatement("Select * from Employee order by sal");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void closeConnection() {
		DButil.closeMyConnection();
	}
	
	@Override
	public void save(Employee e) {
		try {
			psins.setInt(1,e.getEMPNO());
			psins.setString(2,e.getENAME());
			psins.setDouble(3,e.getSAL());
			
			psins.executeUpdate();
		}catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}


	@Override
	public List<Employee> getAllEmployes() {
		
		try {
			List<Employee> list = new ArrayList<>();
			ResultSet rs = psget.executeQuery();
			while(rs.next()) {
				list.add(new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3)));
			}
			return list;
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public Employee getById(int EMPNO) {
		try {
			psgetById.setInt(1,EMPNO);
			ResultSet rs = psgetById.executeQuery();
			if(rs.next()){
				return new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3));
			}
			
		}catch(SQLException e) {
				e.printStackTrace();
			}
		return null;
	}


	@Override
	public boolean getDeleteById(int EMPNO) {
		try {
			psdelById.setInt(1,EMPNO);
			int n = psdelById.executeUpdate();
			return n>0?true:false;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean getModifySal(int EMPNO, double SAL) {
		try {
			psUpdate.setDouble(1,SAL);
			psUpdate.setInt(2,EMPNO);
			int n = psUpdate.executeUpdate();
			return n > 0?true:false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public List<Employee> DisplaySort() {
		List<Employee> list = new ArrayList<>();
		try {
			ResultSet rs = psSort.executeQuery();
			while(rs.next()) {
				list.add(new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3)));
			}
			return list ;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}


	
}
