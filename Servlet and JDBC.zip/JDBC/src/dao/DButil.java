package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DButil {
	private static Connection con;
	
	public static Connection getMyConnection() {
			
			try {
				if(con == null) {
					DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
					String url ="jdbc:mysql://192.168.10.150:3306/dac44?useSSL=false";
					con = DriverManager.getConnection(url,"dac44","welcome");
					
					if(con != null) {
						System.out.println("Connection done");
						System.out.println();
					}
				}
				return con;
				
			}
			catch (SQLException e) {
				
				System.out.println("Error Ocured");
				return null;
			}
	}
	
	public static void closeMyConnection() {
		try {
			if(con!=null)
				con.close();
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
