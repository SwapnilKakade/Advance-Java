package dao;

import java.util.List;

import beans.Employee;

public interface EmployeeDao {

	void save(Employee e);

	List<Employee> getAllEmployes();

	Employee getById(int EMPNO);

	boolean getDeleteById(int EMPNO);

	void closeConnection();

	boolean getModifySal(int eMPNO, double sAL);

	List<Employee> DisplaySort();

	

	

}
