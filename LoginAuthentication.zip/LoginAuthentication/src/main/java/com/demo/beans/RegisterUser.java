package com.demo.beans;

import java.time.LocalDate;
import java.util.Arrays;

public class RegisterUser {
	private int uid;
	private String nm;
	private String addr;
	private String gender ;
	private String [] skill;
	private LocalDate ldt;
	private String city ;
	private String uname;
	
	public RegisterUser(int uid, String nm, String addr, String[] skill, String gender, String passwd, LocalDate ldt, String city, String uname) {
		
		super();
		this.uid = uid;
		this.nm = nm;
		this.addr = addr;
		this.skill = skill;
		this.gender = gender;
		this.ldt = ldt;
		this.city = city;
		this.uname = uname;
	}

	
	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String[] getSkill() {
		return skill;
	}

	public void setSkill(String[] skill) {
		this.skill = skill;
	}

	public LocalDate getLdt() {
		return ldt;
	}

	public void setDt(LocalDate ldt) {
		this.ldt = ldt;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	@Override
	public String toString() {
		return "RegisterUser [uid=" + uid + ", nm=" + nm + ", addr=" + addr + ", gender=" + gender + ", skills="
				+ Arrays.toString(skill) + ", ldt=" + ldt + ", city=" + city + ", uname=" + uname + "]";
	}
	
	
	
}
