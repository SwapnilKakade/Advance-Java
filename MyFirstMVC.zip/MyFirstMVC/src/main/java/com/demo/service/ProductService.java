package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	void addNewProduct(Product p);

	List<Product> getAllProduct();

	Product getById(int pid);

	void updateProduct(Product p);

	int deleteById(int pid);

}
