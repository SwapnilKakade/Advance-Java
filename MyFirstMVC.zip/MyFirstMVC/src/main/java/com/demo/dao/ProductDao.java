package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao {

	int save(Product p);

	List<Product> findAllProduct();

	Product findById(int pid);

	int modifyProduct(Product p);

	int deleteById(int pid);

}
