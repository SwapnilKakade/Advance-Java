package com.demo.service;

import java.util.List;

import com.demo.beans.Department;

public interface DepartmentService{

	List<Department> getAllDepartment();

}
