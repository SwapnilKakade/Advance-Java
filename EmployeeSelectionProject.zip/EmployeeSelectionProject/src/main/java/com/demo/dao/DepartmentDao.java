package com.demo.dao;

import java.util.List;

import com.demo.beans.Department;

public interface DepartmentDao {

	List<Department> getAlldepartments();


}
