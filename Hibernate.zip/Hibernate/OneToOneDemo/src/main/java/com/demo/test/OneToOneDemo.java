package com.demo.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.demo.beans.Student;
import com.demo.beans.Address;
public class OneToOneDemo {

	public static void main(String[] args) {
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Address a2 = new Address(13,"phaltan","pune");
		Student s2 = new Student(200,"kk",a2);
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction(); 
		sess.save(a2);
		sess.save(s2);
		tr.commit();
		sess.close();
		sf.close();
	}

}
