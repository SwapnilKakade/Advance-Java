package com.demo.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.demo.beans.*;

import java.util.Set;
import java.util.HashSet;
public class OneToMany {

	public static void main(String[] args) {

		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session sess = sf.openSession();
		Transaction tr = sess.beginTransaction();
		Address a1 = new Address(1,"baner","pune");
		Address a2 = new Address(2,"aundh","pune");
		Set<Address>aset=new HashSet<>();
		aset.add(a1);
		aset.add(a2);
		Myuser u1 = new Myuser(12,"Sk",aset);
		a1.setMu(a1);
		a2.setMu(a2);
		sess.save(u1);
		sess.save(a1);
		sess.save(a2);
		tr.commit();
		sess.close();
		sf.close();
	}

}
